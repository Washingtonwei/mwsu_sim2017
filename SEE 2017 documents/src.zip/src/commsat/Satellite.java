package commsat;

import hla.rti1516e.*;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.exceptions.AttributeNotDefined;
import hla.rti1516e.exceptions.AttributeNotOwned;
import hla.rti1516e.exceptions.FederateNotExecutionMember;
import hla.rti1516e.exceptions.IllegalName;
import hla.rti1516e.exceptions.NotConnected;
import hla.rti1516e.exceptions.ObjectInstanceNotKnown;
import hla.rti1516e.exceptions.RTIinternalError;
import hla.rti1516e.exceptions.RestoreInProgress;
import hla.rti1516e.exceptions.SaveInProgress;
import hla.rti1516e.AttributeHandle;
import hla.rti1516e.AttributeHandleSet;
import hla.rti1516e.AttributeHandleValueMap;
import hla.rti1516e.ObjectClassHandle;
import hla.rti1516e.ObjectInstanceHandle;
import hla.rti1516e.RTIambassador;
import hla.rti1516e.encoding.EncoderException;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.encoding.HLAboolean;
import hla.rti1516e.encoding.HLAfloat64LE;
import hla.rti1516e.encoding.HLAinteger32BE;
import hla.rti1516e.encoding.HLAunicodeString;

import java.util.logging.Level;
import java.util.logging.Logger;

import java.util.logging.*;

/**
 * 
 * @author Daniel
 */
public class Satellite extends Entity {

	private static final String DEFALT_NAME = "Sat1";
	private static final String STATUS = "Okay" ;
	private static final ReferenceFrame PARENT_REFERENCE_FRAME = ReferenceFrame.MoonCentricInertial ;
	private static final double DEFAULT_TIME = 0;
	private static final String ENTITY_TYPE = "Communications Satellite";

	private String name;
	private String status;
	private ReferenceFrame parentReferenceFrame;
	private double[] vPosition;
	private double[] vVelocity;
	//private double attitude;
	private double time;
	private String entityType;
	private double startTheta;
	
	private Orbit orbit; 


	// HLA Stuff
	private AttributeHandleSet attributeSet;

	private AttributeHandle attributeEntityName;
	private AttributeHandle attributeStatus;
	private AttributeHandle attributeParentRefFrame;
	private AttributeHandle attributePosition;
	private AttributeHandle attributeVelocity;
	//private static AttributeHandle attributeAttitude;
	private AttributeHandle attributeTime;
	private AttributeHandle attributeEntityType;

	// constructor
	// TO DO: 
	public Satellite(String name, TheFederate theFederate) {
		setTheFederate(theFederate);
		setRtiAmbassador(theFederate.getRti_ambassador());
		setEncoderFactory(theFederate.getEncoder_factory());
		setHlaAttributes();
		createEncoders();
		setName(name);
		setHlaName(name + ".Satellite");
		setDefaults();
		reserveObjectInstanceName(getHlaName());
		registerObjectInstance();
	}

	// Set the Default Values, used by the Constructor
	private void setDefaults(){
		startTheta = getStartTheta(getName());
		orbit = new Orbit(startTheta);
		vPosition = orbit.getPosition();
		vVelocity = new double[] {0,0,0};
		status = STATUS;
		time = DEFAULT_TIME;
		entityType = ENTITY_TYPE;
		parentReferenceFrame = PARENT_REFERENCE_FRAME;
	}

	// Setup the Federate to handle a Radio Object
	// this method is called from TheFederate when it is being initialized
	private void setHlaAttributes(){
		try {
			// Get a handle to the PhysicalEntity class.	
			classHandle = rtiAmbassador.getObjectClassHandle("PhysicalEntity");

			// Get handles to all the ReferenceFrame attributes.       
			attributeEntityName = rtiAmbassador.getAttributeHandle(classHandle, "entity_name");
			attributeStatus = rtiAmbassador.getAttributeHandle(classHandle, "status");
			attributeParentRefFrame = rtiAmbassador.getAttributeHandle(classHandle, "parent_reference_frame");
			attributePosition = rtiAmbassador.getAttributeHandle(classHandle, "position");
			attributeVelocity = rtiAmbassador.getAttributeHandle(classHandle, "velocity");
			attributeTime = rtiAmbassador.getAttributeHandle(classHandle, "time");
			attributeEntityType = rtiAmbassador.getAttributeHandle(classHandle, "entity_type");

			// Generate an attribute handle set.
			attributeSet = rtiAmbassador.getAttributeHandleSetFactory().create();
			attributeSet.add(attributeEntityName);
			attributeSet.add(attributeStatus);
			attributeSet.add(attributeParentRefFrame);
			attributeSet.add(attributePosition);
			attributeSet.add(attributeVelocity);
			attributeSet.add(attributeTime);
			attributeSet.add(attributeEntityType);

		} catch (Exception e) {
			System.out.println("Failed to initialize Satellite.");
			System.out.println( e.getMessage() );
		} 

		if (!theFederate.isSatelliteInitialized()) {
			try {
				System.out.println("Satellite not yet initialized for HLA.  Publishing Class Attributes... ");
				rtiAmbassador.publishObjectClassAttributes(classHandle, attributeSet);
				theFederate.setSatelliteInitialized(true);
			} catch (Exception e) {
				System.out.println("Failed to Satellite Radio Class Attributes");
				System.out.println( e.getMessage() );
			}
		}
	}
	
	
	// Register the Radio with HLA Federation
	// Add the radio to the Radio Map in theFederate
	// Store ObjectInstanceHandle Attribute for later use in updating attrs.
	protected void registerObjectInstance() {
		ObjectInstanceHandle a = null;
		a = theFederate.registerObjectInstance(classHandle, getHlaName());
		setObjectInstanceHandle(a);
		// add Radio to Federate
		System.out.println("Satellite Registered ObjectInstanceHandle: " + a);
	}
	

	//update the radio object attribute 
	//TO DO:  need to include other attributes:
	public void postAttributes() {
		try {
			attributeValues =
					rtiAmbassador.getAttributeHandleValueMapFactory().create(1);
		} catch (FederateNotExecutionMember e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotConnected e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
		
		float_64LE_encoder.setValue(theFederate.get_logicalTime().getValue());
		attributeValues.put(attributeTime, float_64LE_encoder.toByteArray());
		
		//Encode Name Value, put Attribute Values Set
		string_encoder.setValue(getName());
		attributeValues.put(attributeEntityName, string_encoder.toByteArray());

		//Encode ParentRefFrame Value, put Attribute Values Set
		string_encoder.setValue(getParentReferenceFrame().toString());
		attributeValues.put(attributeParentRefFrame, string_encoder.toByteArray());

		//Encode Position Vector Value, put Attribute Values Set
		vector_encoder.get(0).setValue(orbit.getPosition()[0]);
		vector_encoder.get(1).setValue(orbit.getPosition()[1]);
		vector_encoder.get(2).setValue(orbit.getPosition()[2]);
		attributeValues.put(attributePosition, vector_encoder.toByteArray());
                string_encoder.setValue(orbit.getLOSStatus());
                attributeValues.put(attributeStatus, string_encoder.toByteArray());
		try {
			rtiAmbassador.updateAttributeValues(objectInstanceHandle, attributeValues, null);
		} catch (AttributeNotOwned e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AttributeNotDefined e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ObjectInstanceNotKnown e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SaveInProgress e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RestoreInProgress e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FederateNotExecutionMember e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotConnected e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RTIinternalError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	private double getStartTheta(String name){
		double startTheta = 0f;
		if ( name.equals("Sat2") ) {startTheta = Math.PI/2;}
		else if ( name.equals("Sat3") ) {startTheta = Math.PI;}
		else if ( name.equals("Sat4") ) {startTheta = Math.PI*3/2;}
		return startTheta;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public ReferenceFrame getParentReferenceFrame() {
		return parentReferenceFrame;
	}

	public void setParentReferenceFrame(ReferenceFrame parentReferenceFrame) {
		this.parentReferenceFrame = parentReferenceFrame;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}

	public Orbit getOrbit() {
		return orbit;
	}

	public void setOrbit(Orbit orbit) {
		this.orbit = orbit;
	}


}