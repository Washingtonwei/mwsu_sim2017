package commsat;

import hla.rti1516e.AttributeHandleSet;
import hla.rti1516e.AttributeHandleValueMap;
import hla.rti1516e.ObjectClassHandle;
import hla.rti1516e.ObjectInstanceHandle;
import hla.rti1516e.RTIambassador;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.encoding.HLAboolean;
import hla.rti1516e.encoding.HLAfixedArray;
import hla.rti1516e.encoding.HLAfloat32LE;
import hla.rti1516e.encoding.HLAfloat64LE;
import hla.rti1516e.encoding.HLAinteger16LE;
import hla.rti1516e.encoding.HLAinteger32BE;
import hla.rti1516e.encoding.HLAinteger32LE;
import hla.rti1516e.encoding.HLAunicodeString;
import hla.rti1516e.exceptions.AttributeNotDefined;
import hla.rti1516e.exceptions.FederateNotExecutionMember;
import hla.rti1516e.exceptions.NotConnected;
import hla.rti1516e.exceptions.ObjectClassNotDefined;
import hla.rti1516e.exceptions.ObjectClassNotPublished;
import hla.rti1516e.exceptions.ObjectInstanceNameInUse;
import hla.rti1516e.exceptions.ObjectInstanceNameNotReserved;
import hla.rti1516e.exceptions.RTIinternalError;
import hla.rti1516e.exceptions.RestoreInProgress;
import hla.rti1516e.exceptions.SaveInProgress;

public class Entity {
	private String name;
	
	protected RTIambassador rtiAmbassador;
	protected EncoderFactory encoderFactory;
	protected TheFederate theFederate;
	
	protected  HLAunicodeString           string_encoder ;
	protected  HLAinteger32LE 			  integer_32LE_encoder;
    protected  HLAfloat64LE               float_64LE_encoder ;
    protected  HLAfloat32LE               float_32LE_encoder ;
    protected  HLAboolean 				  boolean_encoder ;
    protected  HLAinteger32BE			  integer_encoder;
    protected  HLAfixedArray<HLAfloat64LE> vector_encoder;
    
	// Class data.
    protected static boolean            initialized = false;
    protected static final boolean      debug = false;
	
	protected AttributeHandleSet attributeSet;
	protected ObjectClassHandle classHandle;
	protected AttributeHandleValueMap attributeValues;
	protected ObjectInstanceHandle objectInstanceHandle;
	
	protected String HlaName ;
	
	public enum ReferenceFrame {
		SolarSystemBarycentricInertial,
		EarthMoonBarycentricInertial,
		SunCentricInertial,
		EarthCentricInertial,
		MoonCentricInertial,
		EarthCentricFixed,
		MoonCentricFixed,
	}
	
	protected void createEncoders() {
	      try {
			string_encoder = encoderFactory.createHLAunicodeString();
			integer_32LE_encoder = encoderFactory.createHLAinteger32LE();
			float_64LE_encoder = encoderFactory.createHLAfloat64LE();
			float_32LE_encoder = encoderFactory.createHLAfloat32LE();
            vector_encoder = encoderFactory.createHLAfixedArray(
                    encoderFactory.createHLAfloat64LE(),
                    encoderFactory.createHLAfloat64LE(),
                    encoderFactory.createHLAfloat64LE());
		} catch (Exception e) {
			System.out.println("Failed to initialize Encoders.");
			System.out.println( e.getMessage() );
		}
	}
	
	protected void reserveObjectInstanceName(String name) {
		theFederate.reserveObjectInstanceName(name);
	}
		
	
	public void setRtiAmbassador(RTIambassador rti_ambassador) {
		this.rtiAmbassador = rti_ambassador;
	}
	
	public void setTheFederate(TheFederate theFederate) {
		this.theFederate = theFederate;
	}
	
	public void setEncoderFactory(EncoderFactory encoderFactory) {
		this.encoderFactory = encoderFactory;
	}
	
	   
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public ObjectInstanceHandle getObjectInstanceHandle() {
		return objectInstanceHandle;
	}

	public void setObjectInstanceHandle(ObjectInstanceHandle objectInstanceHandle) {
		this.objectInstanceHandle = objectInstanceHandle;
	}

	public String getHlaName() {
		return HlaName;
	}

	public void setHlaName(String hlaName) {
		HlaName = hlaName;
	}

	public ObjectClassHandle getObjectClassHandle() {
		return classHandle;
	}
	
	
}
