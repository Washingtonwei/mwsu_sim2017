package commsat;

import hla.rti1516e.InteractionClassHandle;
import hla.rti1516e.ParameterHandle;
import hla.rti1516e.ParameterHandleValueMap;
import hla.rti1516e.RTIambassador;
import hla.rti1516e.encoding.HLAboolean;
import hla.rti1516e.encoding.HLAunicodeString;
import hla.rti1516e.exceptions.*;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;



/**
 * @author dbulgatz
 * The purpose of this class is to allow sending messages from the command line 
 * The constructor requires a "TheFederate" object
 * User must know the 
 */
class UserIO implements Runnable {
	private static final String DELIMETER = "[:]";
    
    private TheFederate theFederate;
    protected RTIambassador rtiAmbassador;
    private HLAunicodeString stringEncoder;
    private ParameterHandleValueMap parameters;
    private HLAboolean booleanEncoder;
    private InteractionClassHandle message;
    private static ParameterHandle parameterSource;
	private static ParameterHandle parameterDestination;
	private static ParameterHandle parameterIsBroadcast;
	private static ParameterHandle parameterPayload;
    private static InteractionClassHandle rxMessage;
    private static InteractionClassHandle txMessage;
    
    public volatile static boolean quit = false;
    
    //Constructor
    public UserIO(TheFederate theFederate) {
    	setTheFederate(theFederate);
    	try {
			hlaInit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	//printRadios();
    }
    
    /* BUG: This function seems to delete the radios from the list of radios.
    public void printRadios(){
    	   Iterator it = theFederate.getRadios().entrySet().iterator();
    	    while (it.hasNext()) {
    	        Map.Entry pairs = (Map.Entry)it.next();
    	        Radio radio = theFederate.getRadios().get(pairs.getKey());
    	        System.out.println("Radio Name:  " + radio.getName() + "Radio Inst:" + radio.getObjectInstanceHandle());
    	        it.remove(); // avoids a ConcurrentModificationException
    	    }	
    }
    */
    
    private void hlaInit() throws Exception {
        stringEncoder = theFederate.getEncoder_factory().createHLAunicodeString();
        booleanEncoder = theFederate.getEncoder_factory().createHLAboolean();
        message = rtiAmbassador.getInteractionClassHandle("Radio_message");
        parameters = rtiAmbassador.getParameterHandleValueMapFactory().create(1);
		parameterSource = rtiAmbassador.getParameterHandle(message, "source");
        parameterDestination = rtiAmbassador.getParameterHandle(message, "destination");
        parameterIsBroadcast = rtiAmbassador.getParameterHandle(message, "is_broadcast");
        parameterPayload = rtiAmbassador.getParameterHandle(message, "Payload");
        txMessage = rtiAmbassador.getInteractionClassHandle("Radio_message.TX_message");
        rxMessage = rtiAmbassador.getInteractionClassHandle("Radio_message.RX_message");
        
        rtiAmbassador.subscribeInteractionClass(rxMessage);
        rtiAmbassador.publishInteractionClass(txMessage);
    }
    


    @Override
    public void run() {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		JFrame frame = new JFrame();
		ImageIcon icon = new ImageIcon();
		Object[] possibilities = null;
		String input = "Sat1:Sat2:_";

        // Now just wait for user input
        while (!quit) {
			input = (String) JOptionPane.showInputDialog(
							frame,
							"Send a Message in the format Sender : Receiver : Message :\n"
							+ "To exit, type . <ENTER>",
							"Send a Radio Radio Message", JOptionPane.PLAIN_MESSAGE,
							icon, possibilities, input);
			if ((input != null) && input.length() > 0 ) {
				processInputString(input);
				System.out.println("Message Sent: " + input);
			} else { //input.equals(".")
                    System.out.println("exit");
                    quit = true;
                }
		}
	}

    private void processInputString(String input){
                    String tokens[] = input.split(DELIMETER);
                    String source = tokens[0];
                    String destination = tokens[1];
                    String payload = tokens[2];
                    
                    //broadcast to all if destination is empty
                    booleanEncoder.setValue(destination.equals(""));
                    parameters.put(parameterIsBroadcast, booleanEncoder.toByteArray());
 
                    stringEncoder.setValue(source);
                    parameters.put(parameterSource, stringEncoder.toByteArray());
                    
                    stringEncoder.setValue(destination);
                    parameters.put(parameterDestination, stringEncoder.toByteArray()); 
                    
                    stringEncoder.setValue(payload);
                    parameters.put(parameterPayload, stringEncoder.toByteArray());
                    
                    try {
						rtiAmbassador.sendInteraction(txMessage, parameters, null);
					} catch (Exception e) {
			//TODO Catch Exception
                }
            }

	public void setTheFederate(TheFederate theFederate) {
		this.theFederate = theFederate;
		this.rtiAmbassador = theFederate.getRti_ambassador();
	}
}
