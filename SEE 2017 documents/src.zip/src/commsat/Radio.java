package commsat;

import java.util.logging.Level;
import java.util.logging.Logger;

import hla.rti1516e.AttributeHandle;
import hla.rti1516e.AttributeHandleValueMap;
import hla.rti1516e.ObjectClassHandle;
import hla.rti1516e.ObjectInstanceHandle;
import hla.rti1516e.RTIambassador;
import hla.rti1516e.exceptions.AttributeNotDefined;
import hla.rti1516e.exceptions.AttributeNotOwned;
import hla.rti1516e.exceptions.FederateNotExecutionMember;
import hla.rti1516e.exceptions.NotConnected;
import hla.rti1516e.exceptions.ObjectClassNotDefined;
import hla.rti1516e.exceptions.ObjectInstanceNotKnown;
import hla.rti1516e.exceptions.RTIexception;
import hla.rti1516e.exceptions.RTIinternalError;
import hla.rti1516e.exceptions.RestoreInProgress;
import hla.rti1516e.exceptions.SaveInProgress;



public class Radio extends Entity {
	// Radio Attribute Defaults
	private static final float TX_FREQ = 1e8F ;
	private static final float TX_POWER = 1.0F ;
	private static final enableState TX_ENABLE = enableState.Enabled ;
	private static final float RX_REQUIRED_SIGNAL_STR = 0.5F ;
	private static final float RX_FREQ =  1.0e8F ;
	private static final enableState RX_ENABLE = enableState.Enabled ;
	private static final float ELEVATION = 1.0E6F ;
	private static final boolean IS_ROUTER = true ;

	public ObjectInstanceHandle objectInstanceHandle = null;
	private float txFreq;
	private float txPower; 
	private enableState txEnable;
	private float rxReqSigStr;
	private float rxFreq;
	private enableState rxEnable;
	private float elevation;
	private boolean isRouter;

	private Satellite satellite;  

	private static AttributeHandle attributeName;
	private static AttributeHandle attributeElevation;
	private static AttributeHandle attributeTxPower;
	private static AttributeHandle attributeTxFreq;
	private static AttributeHandle attributeTxEnable;
	private static AttributeHandle attributeRxReqSignalStr;
	private static AttributeHandle attributeRxFreq;
	private static AttributeHandle attributeRxEnable;
	private static AttributeHandle attributeIsRouter;

	public enum enableState {
		Enabled(1), Disabled(0);

		private int code;

		private enableState(int c) {
			code = c;
		}

		public int getCode() {
			return code;
		}
	}

	// constructor
	public Radio(Satellite satellite, TheFederate theFederate) {
		setTheFederate(theFederate);
		setRtiAmbassador(theFederate.getRti_ambassador());
		setEncoderFactory(theFederate.getEncoder_factory());
		setHlaAttributes();
		createEncoders();
		setName(satellite.getName());
		setHlaName(getName() + ".Radio");
		setSatellite(satellite);
		setDefaults();
		reserveObjectInstanceName(getHlaName());
		registerObjectInstance();
		postAttributes();
	}
	
	
	// construct to use when HLA Discovers and Object Instance
	public Radio(ObjectInstanceHandle theObject, String theObjectInstanceName) {
		setTheFederate(theFederate);
		setRtiAmbassador(theFederate.getRti_ambassador());
		setEncoderFactory(theFederate.getEncoder_factory());
		setHlaAttributes();
		createEncoders();
		setObjectInstanceHandle(theObject);
		setHlaName(theObjectInstanceName);
	}

	
	private void setDefaults(){
		txFreq = TX_FREQ;
		txPower = TX_POWER;
		txEnable = TX_ENABLE;
		rxReqSigStr = RX_REQUIRED_SIGNAL_STR;
		rxFreq = RX_FREQ;
		rxEnable = RX_ENABLE;
		elevation = ELEVATION;
		isRouter = IS_ROUTER;
	}

	
	private void setHlaAttributes(){
		try {
			// Get a handle to the Radio class.	
			classHandle = rtiAmbassador.getObjectClassHandle("Radio");

			// Get handles to all the ReferenceFrame attributes.       
			attributeName = rtiAmbassador.getAttributeHandle(classHandle, "radio_name");
			attributeElevation = rtiAmbassador.getAttributeHandle(classHandle, "elevation");
			attributeTxPower = rtiAmbassador.getAttributeHandle(classHandle, "TX_power");
			attributeTxFreq = rtiAmbassador.getAttributeHandle(classHandle, "TX_frequency");
			attributeTxEnable = rtiAmbassador.getAttributeHandle(classHandle, "TX_enable");
			attributeRxReqSignalStr = rtiAmbassador.getAttributeHandle(classHandle, "RX_required_signal_strength");
			attributeRxFreq = rtiAmbassador.getAttributeHandle(classHandle, "RX_frequency");
			attributeRxEnable = rtiAmbassador.getAttributeHandle(classHandle, "RX_enable");
			attributeIsRouter = rtiAmbassador.getAttributeHandle(classHandle, "is_router");

			// Generate an attribute handle set.
			attributeSet = rtiAmbassador.getAttributeHandleSetFactory().create();
			attributeSet.add(attributeName);
			attributeSet.add(attributeElevation);
			attributeSet.add(attributeTxPower);
			attributeSet.add(attributeTxFreq);
			attributeSet.add(attributeTxEnable);
			attributeSet.add(attributeRxReqSignalStr);
			attributeSet.add(attributeRxFreq);
			attributeSet.add(attributeRxEnable);
			attributeSet.add(attributeIsRouter);

		} catch (Exception e) {
			System.out.println("Failed to initialize Radio.");
			System.out.println( e.getMessage() );
		} 
		
		if (!theFederate.isRadioInitialized()) {
			try {
				System.out.println("Radio not yet initialized for HLA.  Publishing Class Attributes. " );
				rtiAmbassador.publishObjectClassAttributes(classHandle, attributeSet);
				theFederate.setRadioInitialized(true);
			} catch (Exception e) {
				System.out.println("Failed to Publish Radio Class Attributes");
				System.out.println( e.getMessage() );
			}
		}
	}


	// Register the Radio with HLA Federation
	// Add the radio to the Radio Map in theFederate
	// Store ObjectInstanceHandle Attribute for later use in updating attrs.
	protected void registerObjectInstance() {
		objectInstanceHandle = theFederate.registerObjectInstance(classHandle, getHlaName());
		setObjectInstanceHandle(objectInstanceHandle);
		// add Radio to Federate
		//theFederate.getRadios().put(objectInstanceHandle, this);
		System.out.println("RADIO Registered ObjectInstanceHandle: " + objectInstanceHandle);
	}
	

	
	//update the radio object attribute 
	//TO DO:  need to include other attributes:
	public void postAttributes() {
		try {
			attributeValues =
					rtiAmbassador.getAttributeHandleValueMapFactory().create(1);
		} catch (FederateNotExecutionMember e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotConnected e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		string_encoder.setValue(getName());
		attributeValues.put(attributeName, string_encoder.toByteArray());
		float_64LE_encoder.setValue(elevation);
		attributeValues.put(attributeElevation, float_64LE_encoder.toByteArray());
		float_32LE_encoder.setValue(txPower);
		attributeValues.put(attributeTxPower, float_32LE_encoder.toByteArray());
		float_32LE_encoder.setValue(txFreq);
		attributeValues.put(attributeTxFreq, float_32LE_encoder.toByteArray());
		integer_32LE_encoder.setValue(txEnable.code);
		attributeValues.put(attributeTxEnable, integer_32LE_encoder.toByteArray());
		
		
		
		try {
			rtiAmbassador.updateAttributeValues(objectInstanceHandle, attributeValues, null);
		} catch (AttributeNotOwned e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AttributeNotDefined e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ObjectInstanceNotKnown e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SaveInProgress e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RestoreInProgress e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FederateNotExecutionMember e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotConnected e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RTIinternalError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void Receive(String source, String destination, String payload, Boolean isBroadcast) {
		if (destination.equals("")) {
			System.out.println("Bad message received: No Destination.");
			return;
		}
		if (source.equals("")) {
			System.out.println("Bad message received: No Source.");
			return;
		}
		if (payload.equals("")) {
			System.out.println("Bad message received: Empty Message.");
			return;
		}
		System.out.print("\n" + source + "->" + destination);
		if (isBroadcast) {
			System.out.print("[ Broadcast ]");
		}
		System.out.println(":" + payload);
		System.out.print("> ");
	}



	public Satellite getSatellite() {
		return satellite;
	}

	public void setSatellite(Satellite satellite) {
		this.satellite = satellite;
	}





}
