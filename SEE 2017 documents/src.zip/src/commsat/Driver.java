package commsat;

import java.util.Scanner;

import hla.rti1516e.FederateAmbassador;
import hla.rti1516e.RTIambassador;
import hla.rti1516e.encoding.EncoderFactory;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Driver {

    public static Boolean use_mak = false;
    public static String IP = "localhost";

    /**
     * @param args
     */
    static final long TIME_TICK = 1000000;        // microseconds.
    static final boolean HLA_CONSTRAIN_TIME = true;  //set to false for debug mode with no HLA Timing

    public static void main(String[] args) {
        String baseName;
        String ipAddress = "";
        double sim_exec_time = 0.0;        // Simulation time in seconds.
        double time_epoch;                 // Start time for simulation.
        double time;                   // Current time.
        long exec_loop_counter = 0;        // Cumulative loop counter.
        boolean continue_execution = true;  // Execution loop control flag.

        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        try {
            if (args.length > 1) {
                if (args[0].equals("mak")) {
                    use_mak = true;
                } else if (args[0].equals("pitch")) {
                    use_mak = false;
                } else {
                    System.out.println("First argument must be the RTI to use. (pitch|mak)");
                    return;
                }
                ipAddress = args[1];
            } else {
                System.out.print("Enter the IP address of the CRC host [localhost]: ");
                ipAddress = in.readLine();
                if (ipAddress.length() == 0) {
                    ipAddress = "localhost";
                }
            }

        } catch (Exception e) {
            Logger.getLogger(Driver.class.getName()).log(Level.SEVERE, null, e);
        }

        /*
         * Scanner scan = new Scanner(System.in);
         *
         * String defaultIpAddress = "192.168.15.2"; //defaultIpAddress =
         * "10.1.116.152"; String defaultBaseName = "Adam";
         *
         * // IP Address System.out.println("Enter an IP address [" +
         * defaultIpAddress + "]: "); ipAddress = scan.nextLine(); ipAddress =
         * ipAddress.equals("") ? defaultIpAddress : ipAddress;
         *
         *
         * // Print System.out.println("IP address: " + ipAddress);
         * //System.out.println("Base name: " + baseName);
         */

        TheFederate theFederate = new TheFederate(ipAddress, TIME_TICK, HLA_CONSTRAIN_TIME);

        System.out.println("Federate Established and Connected!");

        Satellite sat1 = new Satellite("Sat1", theFederate);
        Radio radio1 = new Radio(sat1, theFederate);
        theFederate.addRadio(radio1.objectInstanceHandle, radio1);
        radio1.postAttributes();

        Satellite sat2 = new Satellite("Sat2", theFederate);
        Radio radio2 = new Radio(sat2, theFederate);
        theFederate.addRadio(radio2.objectInstanceHandle, radio2);
        radio2.postAttributes();

        Satellite sat3 = new Satellite("Sat3", theFederate);
        Radio radio3 = new Radio(sat3, theFederate);
        theFederate.addRadio(radio3.objectInstanceHandle, radio3);
        radio3.postAttributes();

        Satellite sat4 = new Satellite("Sat4", theFederate);
        Radio radio4 = new Radio(sat4, theFederate);
        theFederate.addRadio(radio4.objectInstanceHandle, radio4);
        radio4.postAttributes();

        Satellite sat5 = new Satellite("Sat5", theFederate);
        Radio radio5 = new Radio(sat5, theFederate);
        theFederate.addRadio(radio5.objectInstanceHandle, radio5);
        radio5.postAttributes();


        // Set the physical time epoch from the SimConfig object in seconds.
        time = System.currentTimeMillis() / 1000;
        time = 0;
        time_epoch = time * 60 * 60 * 24;

        // Accept input from the command line.
        UserIO userIO = new UserIO(theFederate);
        (new Thread(userIO)).start();

        Orbit os1 = sat1.getOrbit();
        System.out.println("Lunar Base Location [m] (x,y,z) : ");
        System.out.println(os1.getLunarBaseXYZ()[0] + ", "
                + os1.getLunarBaseXYZ()[1] + ", "
                + os1.getLunarBaseXYZ()[2]);

        // Executive run loop.
        while (!UserIO.quit) {
            // Compute the current simulation execution time in seconds.
            sim_exec_time = (exec_loop_counter * TIME_TICK) / 1000000.0;
            // Compute the problem time.
            time = time_epoch + sim_exec_time;

            if (HLA_CONSTRAIN_TIME) {
                // Wait for the time advance grant.
                while (!theFederate.get_timeCanAdvance()) {
                    Thread.yield();
                }
            } else {
                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    System.out.println("\": Unknown error in sleep:");
                    System.out.println(e.getMessage());
                }
            }


            os1.propagateOrbit(Math.PI / 360);
            //printStatus(sat1, time);
            sat1.postAttributes();

            //System.out.println(os1.getTheta() + ", " + os1.getDistanceToLunarBaseTangentPlane());


            sat2.getOrbit().propagateOrbit(Math.PI / 360);
            //printStatus(sat2, time);
            sat2.postAttributes();

            sat3.getOrbit().propagateOrbit(Math.PI / 360);
            //printStatus(sat3, time);
            sat3.postAttributes();

            sat4.getOrbit().propagateOrbit(Math.PI / 360);
            //printStatus(sat4, time);
            sat4.postAttributes();

            sat5.getOrbit().propagateOrbit(Math.PI / 360);
            //printStatus(sat5, time);
            sat5.postAttributes();

            if (HLA_CONSTRAIN_TIME) {
                theFederate.RequestTimeAdvance();
            }

            // Increment the executive loop counter.
            exec_loop_counter++;
        }

        // Try to exit cleanly
        theFederate.resign();
    }

    private static void printStatus(Satellite sat, double time) {
        System.out.println(sat.getName() + " Time: " + time + " |" + sat.getOrbit().toString());
        System.out.println(sat.getOrbit().getPosition()[0] + " " + sat.getOrbit().getPosition()[1] + " " + sat.getOrbit().getPosition()[2]);
    }
}
