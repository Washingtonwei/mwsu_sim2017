package commsat;

import hla.rti1516e.*;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.exceptions.*;
import hla.rti1516e.time.HLAinteger64Time;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connection {

    private static final String DEFAULT_IPADDRESS = "192.168.15.2";
    private static final int CRC_PORT = 8989;
    private static final String FEDERATION_NAME = "SISO Smackdown 1112";
    //private URL[] FOM_MODULES = null;
    private String federateName;

    public Connection(FederateAmbassador federateAmbassador, RTIambassador rtiAmbassador, String rtiHost) {
        try {
            // Connect to the HLA central runtime component (CRC).
            if (Driver.use_mak) {
                System.out.println("Connecting to MAK RTI");
                rtiAmbassador.connect(federateAmbassador, CallbackModel.HLA_IMMEDIATE);
            } else {
                System.out.println("Connecting to Pitch RTI");
                String settingsDesignator = "crcHost=" + rtiHost + "\ncrcPort="
                        + Integer.toString(CRC_PORT);
                rtiAmbassador.connect(federateAmbassador,
                        CallbackModel.HLA_IMMEDIATE, settingsDesignator);
            }
            /*
             * String settingsDesignator = "crcHost=" + rtiHost + "\ncrcPort=" +
             * Integer.toString(CRC_PORT);
             *
             * rtiAmbassador.connect(federateAmbassador,
             * CallbackModel.HLA_IMMEDIATE, settingsDesignator);
             */

            try {
                rtiAmbassador.destroyFederationExecution(FEDERATION_NAME);
            } catch (Exception ignored) {
            }

            String URL_PREFIX = "";
            if (Driver.use_mak) {
                URL_PREFIX = "file://";
            } else {
                URL_PREFIX = "file:/";
            }
            System.out.println("USING URL PREFIX" + URL_PREFIX);

            String workingDir = System.getProperty("user.dir");
            String FOM_DIR = "../../FOMs/";
            URL[] FOM_MODULES;

            FOM_MODULES = new URL[]{
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "SISO_Smackdown_1011_core.xml"),
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "SISO_Smackdown_1011_environ.xml"),
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "SISO_Smackdown_1011_entity.xml"),
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "Smack_radio.xml")
            };

            /*
             * File coreFile = new File(FOM_DIR +
             * "SISO_Smackdown_1011_core.xml"); File environFile = new
             * File(FOM_DIR + "SISO_Smackdown_1011_environ.xml"); File
             * vehicleFile = new File(FOM_DIR +
             * "SISO_Smackdown_1011_entity.xml"); File fddFile = new
             * File(FOM_DIR + "Smack_radio.xml"); try { FOM_MODULES = new URL[]
             * { coreFile.toURI().toURL(), environFile.toURI().toURL(),
             * vehicleFile.toURI().toURL(), fddFile.toURI().toURL() }; } catch
             * (Exception ignore) {}
             */

            // Try to start the federation. Ignore exception if the federation already exists.

            try {
                rtiAmbassador.createFederationExecution(FEDERATION_NAME, FOM_MODULES, "HLAinteger64Time");
                //rtiAmbassador.createFederationExecution(FEDERATION_NAME, FOM_MODULES);
            } catch (FederationExecutionAlreadyExists ignored) {
            }

            federateName = "LCANSat";

            try {
                rtiAmbassador.joinFederationExecution(federateName,
                        "UAHuntsville Sattelite Constellation", FEDERATION_NAME, FOM_MODULES);

                System.out.println("Joined Federation");
            } catch (CouldNotCreateLogicalTimeFactory time_error) {
                System.out.println("Logical time creation error:");
                System.out.println(time_error.getMessage());
            } catch (FederateNameAlreadyInUse e) {
                System.out.println("Federate Name in USE:");
                System.out.println(e.getMessage());
            } catch (FederationExecutionDoesNotExist fed_exist_error) {
                System.out.print(FEDERATION_NAME);
                System.out.println("\" does not exist:");
                System.out.println(fed_exist_error.getMessage());
            } catch (InconsistentFDD fdd_consistency_error) {
                System.out.println("FDD consitency error:");
                System.out.println(fdd_consistency_error.getMessage());
            } catch (ErrorReadingFDD fdd_read_error) {
                System.out.println("Could not read FDD:");
                System.out.println(fdd_read_error.getMessage());
            } catch (CouldNotOpenFDD fdd_open_error) {
                System.out.println("Could not Open FDD:");
                System.out.println(fdd_open_error.getMessage());
            } catch (SaveInProgress save_in_progress_error) {
                System.out.println("Save in Progress Error:");
                System.out.println(save_in_progress_error.getMessage());
            } catch (RestoreInProgress restore_in_progress_error) {
                System.out.println("Restore in Progress Error:");
                System.out.println(restore_in_progress_error.getMessage());
            } catch (FederateAlreadyExecutionMember fed_exec_error) {
                System.out.println("Already joined to the federation:");
                System.out.println(fed_exec_error.getMessage());
            } catch (NotConnected not_connected_error) {
                System.out.println("Not Connected to the federation:");
                System.out.println(not_connected_error.getMessage());
            } catch (CallNotAllowedFromWithinCallback e) {
                System.out.println("Call Not Allowed within callback:");
                e.printStackTrace();
            } catch (RTIinternalError rti_error) {
                System.out.println("Internal RTI error detected on join:");
                System.out.println(rti_error.getMessage());
            }


            // Enable asynchronous data delivery.
            try {
                rtiAmbassador.enableAsynchronousDelivery();
            } catch (RTIinternalError rti_error) {
                System.out.println("Internal RTI error detected:");
                System.out.println(rti_error.getMessage());

            } catch (Exception e) {
                System.out.println("Unexpected/unhandled error detected:");
                System.out.println(e.getMessage());
            }

        } catch (Exception ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }

    } // end Constructor

    public void resign(RTIambassador rtiAmbassador) {
        try {
            rtiAmbassador.resignFederationExecution(ResignAction.DELETE_OBJECTS_THEN_DIVEST);
            try {
                rtiAmbassador.destroyFederationExecution(FEDERATION_NAME);
            } catch (FederatesCurrentlyJoined ignored) {
            }
            rtiAmbassador.disconnect();
            rtiAmbassador = null;
        } catch (Exception ex) {
            Logger.getLogger(TheFederate.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
} // end class
