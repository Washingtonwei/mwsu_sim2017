package commsat;

import hla.rti1516e.*;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.exceptions.*;
import hla.rti1516e.time.HLAfloat64Time;
import hla.rti1516e.time.HLAinteger64Interval;
import hla.rti1516e.time.HLAinteger64Time;
import hla.rti1516e.time.HLAinteger64TimeFactory;

public class TheFederate extends NullFederateAmbassador{

	String rtiHost = "localhost";
	private static final String DEFAULT_RTI_HOST = "localhost";

	// Debug flag.
    private static final boolean debug = false;
    // Declare HLA housekeeping stuff.
    private RTIambassador rti_ambassador;
    private FederateAmbassador theFederate;

    // Only initialize the Radio and Satellite once.  Will check each time an instance
    // is created.
    private boolean radioInitialized = false;
    private boolean satelliteInitialized = false;
    
	private EncoderFactory encoder_factory;
    private Connection connection;

    private static volatile boolean _reservationComplete;
    private static volatile boolean _reservationSucceeded;
    private static final Object _reservationSemaphore = new Object();

    //Time Flags
    private static Boolean _desireTimeConstraint = true;
    private static Boolean _isTimeConstrained = false;
    private static Boolean _isTimeRegulating = false;
    private static Boolean _timeCanAdvance = false;
    private static Boolean _end = false;
    
    //Time Data
    private static HLAinteger64Time _logicalTime;
    private static HLAinteger64Interval _logicalTimeInterval;
    private static HLAinteger64TimeFactory _timeFactory;
    private static TimeQueryReturn _startingGALT;
  //Debug flags
    private static Boolean _debugMessageLvl1 = false;
    private static Boolean _debugMessageLvl2 = false;
    
    // Store a list of known radios.
    private final Map<ObjectInstanceHandle, Radio> radios = new HashMap<ObjectInstanceHandle,Radio>();
    

    /*
    public TheFederate(){
    	this(DEFAULT_RTI_HOST, 1000000, true);
    }
    */
    
	public TheFederate(String rtiHost, long timetick, boolean HLA_TIME_CONSTRAINED){
    	this.rtiHost = rtiHost;
    	 try {
			// related services used in the application.
			RtiFactory rti_factory = RtiFactoryFactory.getRtiFactory();
			
			// Get the RTI ambassador.
			rti_ambassador = rti_factory.getRtiAmbassador();
			
			// Get the encoder factory used to build encoders for the types.
			encoder_factory = rti_factory.getEncoderFactory();
			
		} catch (Exception e) {
            // Something went wrong in getting the ambassador or encoder factory.
            System.out.println("Unable to create RTI ambassador.");
            System.out.println(e.getMessage());
		}
    	 
    	connection = new Connection(this, rti_ambassador, rtiHost);
    	
    	_desireTimeConstraint =  HLA_TIME_CONSTRAINED;
    	
    	try {
			System.out.println("RTI Amb" + rti_ambassador.getTimeFactory());
		} catch (FederateNotExecutionMember e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (NotConnected e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	
        try {
            // Get the logical time factory.
 
            _timeFactory = (HLAinteger64TimeFactory) rti_ambassador.getTimeFactory();
            // Make the local logical time object.
            if (_debugMessageLvl2) {
                System.out.println("make time");
            }
            _logicalTime = _timeFactory.makeInitial();
            if (_logicalTime == null) {
                System.out.println("make time failed");
            }
            // Make the local logical time interval.
            _logicalTimeInterval = _timeFactory.makeInterval(timetick);

            // Make this federate time constrained.
            if (_desireTimeConstraint) {

                // Enable time constraint.
            	rti_ambassador.enableTimeConstrained();

                if (_debugMessageLvl2) {
                    System.out.println(" timing init");
                }
                // Wait for time constraint to take affect.
                while (!_isTimeConstrained) {

                    if (_debugMessageLvl2) {
                        System.out.println(" waiting for time constraint");
                    }
                    Thread.yield();
                }

            }
        } catch (RTIexception e) {
            System.out.println("Time Constraint Error" + e.toString());
        }
 	 
        try {
            _startingGALT = rti_ambassador.queryGALT();
            if (_startingGALT.timeIsValid) {
            	rti_ambassador.timeAdvanceRequest(_startingGALT.time);
                _logicalTime = (HLAinteger64Time) _startingGALT.time;
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

 
    }
    
    public void resign() {
        connection.resign(rti_ambassador);
    }

    public RTIambassador getRti_ambassador() {
		return rti_ambassador;
	}

	public EncoderFactory getEncoder_factory() {
		return encoder_factory;
	}

	public Connection getConnection() {
		return connection;
	}
	
    public void setConnection(Connection connection) {
		this.connection = connection;
	}

    public String getRtiHost() {
		return rtiHost;
	}

	public void setRtiHost(String rtiHost) {
		this.rtiHost = rtiHost;
	}
	
	public void reserveObjectInstanceName(String name) {

		try {
			_reservationComplete = false;
			synchronized (_reservationSemaphore) {
				rti_ambassador.reserveObjectInstanceName(name);
				// Wait for response from RTI
				while (!_reservationComplete) {
					try {
						_reservationSemaphore.wait();
					} catch (InterruptedException ignored) {
					}
				}
			}

		} catch (IllegalName e) {
			System.out.println("Illegal name.");
		} catch (RTIexception e) {
			System.out.println("RTI exception when reserving name: " + e.getMessage());
			return;
		}

	}
    
    public ObjectInstanceHandle registerObjectInstance(ObjectClassHandle objectClassHandle, String theObjectName ){
    	ObjectInstanceHandle a = null;
    	try {
			a = rti_ambassador.registerObjectInstance(objectClassHandle, theObjectName);
		} catch (ObjectInstanceNameInUse e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ObjectInstanceNameNotReserved e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ObjectClassNotPublished e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ObjectClassNotDefined e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SaveInProgress e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RestoreInProgress e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FederateNotExecutionMember e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotConnected e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RTIinternalError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return a;
    }

    
    
	public boolean isRadioInitialized() {
		return radioInitialized;
	}

	public void setRadioInitialized(boolean radioInitialized) {
		this.radioInitialized = radioInitialized;
	}

	public boolean isSatelliteInitialized() {
		return satelliteInitialized;
	}

	public void setSatelliteInitialized(boolean satelliteInitialized) {
		this.satelliteInitialized = satelliteInitialized;
	}
	
	public Map<ObjectInstanceHandle, Radio> getRadios() {
		return radios;
	}

    public void addRadio(ObjectInstanceHandle h, Radio r) {
        radios.put(h, r);
    }
	
    
	public void RequestTimeAdvance(){
			try {
				_timeCanAdvance = false;
				_logicalTime = _logicalTime.add(_logicalTimeInterval);
				//System.out.println("Logical time is: " +  _logicalTime );
				rti_ambassador.timeAdvanceRequest(_logicalTime);
			} catch (IllegalTimeArithmetic e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (LogicalTimeAlreadyPassed e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvalidLogicalTime e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InTimeAdvancingState e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RequestForTimeRegulationPending e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RequestForTimeConstrainedPending e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SaveInProgress e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RestoreInProgress e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FederateNotExecutionMember e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NotConnected e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (RTIinternalError e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
	
    
	//  ******************************************************
    //  ************************* OVERRIDEs ******************
	
    @Override
    public final void objectInstanceNameReservationSucceeded(String objectName) {
        synchronized (_reservationSemaphore) {
            _reservationComplete = true;
            _reservationSucceeded = true;
            _reservationSemaphore.notifyAll();
        }
    }

    @Override
    public final void objectInstanceNameReservationFailed(String objectName) {
        synchronized (_reservationSemaphore) {
            _reservationComplete = true;
            _reservationSucceeded = false;
            _reservationSemaphore.notifyAll();
        }
    }
   

    @Override
    public void timeConstrainedEnabled(LogicalTime time)
            throws FederateInternalError {
        _isTimeConstrained = true;
        _logicalTime = (HLAinteger64Time) time;
    }

    @Override
    public void timeAdvanceGrant(LogicalTime theTime)
            throws FederateInternalError {
        // Check granted time requested time.
        if (theTime.compareTo(_logicalTime) >= 0) {
            _timeCanAdvance = true;
            if (_debugMessageLvl2) {
                System.out.println("time advance granted");
            }
        }
    }
    
    
    /*
    @Override
    public void discoverObjectInstance(
            ObjectInstanceHandle theObject,
            ObjectClassHandle theObjectClass,
            String theObjectInstanceName) {

        try {
            // Initialize the types of objects we want to discover.
            final ObjectClassHandle radioObject =
            		rti_ambassador.getObjectClassHandle("Radio");

             if (theObjectClass.equals(radioObject)) {
                System.out.println("Discovered new HLA radio: " + theObjectInstanceName);
                if (!radios.containsKey(theObject)){
                	System.out.println("ADDING A RADIO!!!!");
                	radios.put(theObject, new Radio(theObject, theObjectInstanceName));
                }
            } 
        } catch (Exception ex) {
        }
    }
    
    @Override
    public void removeObjectInstance(ObjectInstanceHandle theObject,
            byte[] userSuppliedTag,
            OrderType sentOrdering,
            SupplementalRemoveInfo removeInfo) {
        try {
            if (radios.containsKey(theObject)) {
                // Retrieve the radio from the map.
                Radio radio = radios.get(theObject);

                // Remove the radio from the list.
                System.out.println("Removing Radio: " + radio.getName());
                radios.remove(theObject);
            }
        } catch (Exception e) {
            Logger.getLogger("TheFederate").log(Level.SEVERE, null, e);
        }
    }
    */
    
    
    @Override
    public final void provideAttributeValueUpdate(ObjectInstanceHandle theObject,
            AttributeHandleSet theAttributes, byte[] userSuppliedTag) {
    	System.out.println("Providing Updated Attributes for.. " + theObject);
   
    	 if (radios.containsKey(theObject)) {
             // Retrieve the radio from the map.
             Radio radio = radios.get(theObject);
             System.out.println("Providing Updated Attributes for Radio: " + radio.getName());
             radio.postAttributes();
        } else {
            System.out.println("I don't know who that is.");
        }
    }

	public static Boolean get_timeCanAdvance() {
		return _timeCanAdvance;
	}

	public static HLAinteger64Time get_logicalTime() {
		return _logicalTime;
	}

	public static void set_logicalTime(HLAinteger64Time _logicalTime) {
		TheFederate._logicalTime = _logicalTime;
	}
	

}
