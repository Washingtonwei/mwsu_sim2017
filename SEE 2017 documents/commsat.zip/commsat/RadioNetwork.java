package commsat;

import hla.rti1516e.*;
import hla.rti1516e.encoding.DecoderException;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.encoding.HLAboolean;
import hla.rti1516e.encoding.HLAunicodeString;
import hla.rti1516e.exceptions.FederateInternalError;
import hla.rti1516e.exceptions.FederatesCurrentlyJoined;
import hla.rti1516e.exceptions.FederationExecutionAlreadyExists;
import hla.rti1516e.exceptions.FederationExecutionDoesNotExist;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

class RadioNetwork extends NullFederateAmbassador {

    private static final double[] ORIGIN = {0, 0, 0};
    private static final double LUNAR_RADIUS = 1738100-2000; // Lunar radius at Hadley Rille with margin.
    private static final double RADIO_LAMBDA = 0.013;
    private static final boolean RANGE_ENABLED = false;
    private static final boolean LOS_ENABLED = true;
    private RTIambassador _rtiAmbassador;
    private final String[] _args;
    private InteractionClassHandle _message;
    private InteractionClassHandle TX_message;
    private InteractionClassHandle RX_message;
    private ParameterHandle _parameterSource;
    private ParameterHandle _parameterDestination;
    private ParameterHandle _parameterIsBroadcast;
    private ParameterHandle _parameterPayload;
    private ObjectInstanceHandle _userId;
    // Store a list of known HLA objects.
    private final Map<ObjectInstanceHandle, ObjectClassHandle> objects =
            new HashMap<ObjectInstanceHandle, ObjectClassHandle>();
    // Store a list of known entities.
    private final Map<ObjectInstanceHandle, cEntity> entities =
            new HashMap<ObjectInstanceHandle, cEntity>();
    // Store a list of known radios.
    private final Map<ObjectInstanceHandle, cRadio> radios =
            new HashMap<ObjectInstanceHandle, cRadio>();
    // Store a list of known reference frames.
    private final Map<ObjectInstanceHandle, cReferenceFrame> frames =
            new HashMap<ObjectInstanceHandle, cReferenceFrame>();
    // Map to store ojbect names to Oject Instance Handles
    private Map<String, ObjectInstanceHandle[]> nameHandleMap =
            new HashMap<String, ObjectInstanceHandle[]>();
    private String _me;
    private static final int CRC_PORT = 8989;
    private static final String FEDERATION_NAME = "SISO Smackdown 1112";
    private EncoderFactory _encoderFactory;
    private volatile boolean wait_on_reference_frame_discovery = true;
    private static int discovered_reference_frames = 0;
    private Boolean use_mak = false;
    private volatile boolean initialized = false;

    public static void main(String[] args) {
        new RadioNetwork(args).run();
    }

    private RadioNetwork(String[] args) {
        _args = args;
    }

    private void addRadiotoNameHandleMap(String radioName, ObjectInstanceHandle radioHandle) {
        if (nameHandleMap.get(radioName) == null) {
            nameHandleMap.put(radioName, new ObjectInstanceHandle[2]);
        }
        // Adds the SomeObjectInstanceHandle to ObjectInstanceHandle[] located at key
        nameHandleMap.get(radioName)[0] = radioHandle;

        /*
         * String output = "Name Handle Map Keys: "; for (String key :
         * nameHandleMap.keySet()) { output += key; }
         * System.out.println(output);
         */
    }

    private void addEntitytoNameHandleMap(String entityName, ObjectInstanceHandle entityHandle) {
        if (nameHandleMap.get(entityName) == null) {
            nameHandleMap.put(entityName, new ObjectInstanceHandle[2]);
        }
        // Adds the SomeObjectInstanceHandle to ObjectInstanceHandle[] located at key
        nameHandleMap.get(entityName)[1] = entityHandle;
        /*
         * String output = "Name Handle Map Keys: "; for (String key :
         * nameHandleMap.keySet()) { output += key; }
         * System.out.println(output);
         */
    }

    private double[] getRadioPosition(String radioName) {
        ObjectInstanceHandle radio_handle = nameHandleMap.get(radioName)[0];
        ObjectInstanceHandle entity_handle = nameHandleMap.get(radioName)[1];
        cRadio a = radios.get(radio_handle);
        cEntity b = entities.get(entity_handle);
        double[] position = b.getPosition();
        /// @todo fix this equation to divide the elevation into the x, y, and z components.
        double elevation = a.getElevation();
        position[0] += elevation;
        position[1] += elevation;
        position[2] += elevation;
        return position;
    }

    private void removeKeyfromNameHandleMap(String objectName) {
        if (nameHandleMap.get(objectName) != null) {
            nameHandleMap.remove(objectName);
        }
    }

    /**
     * Calculate distance between two points.
     *
     * @param p1 First point
     * @param p2 Second point
     * @return Distance between the two points.
     */
    private double calcDistance(double[] p1, double[] p2) {
        return Math.pow(Math.pow(p1[0] - p2[0], 2) + Math.pow(p1[1] - p2[1], 2)
                + Math.pow(p1[2] - p2[2], 2), 0.5);
    }

    /**
     * Calculate free-space path loss.
     *
     * For the purposes of radios near the moon and distant from one another,
     * FSPL gives us a "close enough" algorithm to calculate signal loss.
     *
     * @param d Distance between radio nodes.
     * @param l Signal wavelength (lambda) in meters.
     * @return Free space path loss. Multiply the original signal by this
     * amount.
     *
     * @warning All I know about radio propogation, I learned from Wikipedia, so
     * assume that this is all completely wrong!!!!
     *
     * http://en.wikipedia.org/wiki/Free-space_path_loss
     */
    private double calcFSPL(double d, double l) {
        return Math.pow(4 * Math.PI * d / l, 2);
    }

    /**
     * Calculate the intersection of a ray and a sphere The line segment is
     * defined from p1 to p2 The sphere is of radius r and centered at sc
     *
     * Algorithm adapted from http://paulbourke.net/geometry/sphereline/
     *
     * @param p1 First point
     * @param p2 Second point
     * @param sc Center of the sphere
     * @param r Radius of the sphere
     * @return true if the ray intersects the shere
     */
    private boolean RaySphere(double[] p1, double[] p2, double[] sc, double r) {
        double a, b, c;
        double bb4ac;
        double[] dp = new double[3];

        dp[0] = p2[0] - p1[0];
        dp[1] = p2[1] - p1[1];
        dp[2] = p2[2] - p1[2];
        a = dp[0] * dp[0] + dp[1] * dp[1] + dp[2] * dp[2];
        b = 2 * (dp[0] * (p1[0] - sc[0]) + dp[1] * (p1[1] - sc[1]) + dp[2] * (p1[2] - sc[2]));
        c = sc[0] * sc[0] + sc[1] * sc[1] + sc[2] * sc[2];
        c += p1[0] * p1[0] + p1[1] * p1[1] + p1[2] * p1[2];
        c -= 2 * (sc[0] * p1[0] + sc[1] * p1[1] + sc[2] * p1[2]);
        c -= r * r;
        bb4ac = b * b - 4 * a * c;
        if (Math.abs(a) < 1e-10 || bb4ac < 0) {
            return true;
        }

        return false;
    }

    /**
     * Calculate the distance between two points.
     *
     * @param p1 First point
     * @param p2 Second point
     * @return Distance between the points.
     */
    private double Distance(double[] p1, double[] p2) {
        return Math.sqrt((p1[0] - p2[0]) * (p1[0] - p2[0])
                + (p1[1] - p2[1]) * (p1[1] - p2[1])
                + (p1[2] - p2[2]) * (p1[2] - p2[2]));
    }

    private void run() {
        try {
            BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

            String rtiHost = "";
            String URL_PREFIX = "";

            if (_args.length > 1) {
                if (_args[0].equals("mak")) {
                    use_mak = true;
                    URL_PREFIX = "file://";
                } else if (_args[0].equals("pitch")) {
                    use_mak = false;
                    URL_PREFIX = "file:/";
                    System.out.println("USING URL PREFIX" + URL_PREFIX);
                } else {
                    System.out.println("First argument must be the RTI to use. (pitch|mak)");
                    return;
                }
                rtiHost = _args[1];
            } else {
                System.out.print("Enter the IP address of the CRC host [localhost]: ");
                rtiHost = in.readLine();
                if (rtiHost.length() == 0) {
                    rtiHost = "localhost";
                }
            }

            try {
                RtiFactory rtiFactory = RtiFactoryFactory.getRtiFactory();
                _rtiAmbassador = rtiFactory.getRtiAmbassador();
                _encoderFactory = rtiFactory.getEncoderFactory();
            } catch (Exception e) {
                System.out.println("Unable to create RTI ambassador.");
                return;
            }

            // Connect to the HLA central runtime component (CRC).
            if (use_mak) {
                System.out.println("Connecting to MAK RTI");
                _rtiAmbassador.connect(this, CallbackModel.HLA_IMMEDIATE);
            } else {
                System.out.println("Connecting to Pitch RTI");
                String settingsDesignator = "crcHost=" + rtiHost + "\ncrcPort="
                        + Integer.toString(CRC_PORT);
                _rtiAmbassador.connect(this,
                        CallbackModel.HLA_IMMEDIATE, settingsDesignator);
            }

            // Register with the federation. If the federation doesn't exist, create it.
            //

            // First destroy any old abandoned instances of the federation.
            try {
                _rtiAmbassador.destroyFederationExecution(FEDERATION_NAME);
            } catch (FederatesCurrentlyJoined ignored) {
            } catch (FederationExecutionDoesNotExist ignored) {
            }

            // Include the FOMS that this federate has an interest in.
            String workingDir = System.getProperty("user.dir");
            String FOM_DIR = "../../FOMs/";
            URL[] FOM_MODULES = new URL[]{
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "SISO_Smackdown_1011_core.xml"),
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "SISO_Smackdown_1011_environ.xml"),
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "SISO_Smackdown_1011_entity.xml"),
                new URL(URL_PREFIX + workingDir + "/" + FOM_DIR + "Smack_radio.xml")
            };

            // Create the federation. If it already exists, ignore the exception.
            try {
                _rtiAmbassador.createFederationExecution(FEDERATION_NAME,
                        FOM_MODULES, "HLAinteger64Time");
            } catch (FederationExecutionAlreadyExists ignored) {
            }

            // Our federate joins the federation
            _rtiAmbassador.joinFederationExecution("Communication Service",
                    "UAHuntsville Communications Service",
                    FEDERATION_NAME, FOM_MODULES);

            // Register all of the HLA object types with the HLA interface.
            cRadio.hla_register(_rtiAmbassador, _encoderFactory);
            cReferenceFrame.hla_register(_rtiAmbassador, _encoderFactory);
            cEntity.hla_register(_rtiAmbassador, _encoderFactory);

            initialized = true;

            // Subscribe and publish interactions
            _message = _rtiAmbassador.getInteractionClassHandle("Radio_message");
            TX_message = _rtiAmbassador.getInteractionClassHandle("Radio_message.TX_message");
            RX_message = _rtiAmbassador.getInteractionClassHandle("Radio_message.RX_message");
            _parameterSource = _rtiAmbassador.getParameterHandle(_message, "source");
            _parameterDestination = _rtiAmbassador.getParameterHandle(_message, "destination");
            _parameterIsBroadcast = _rtiAmbassador.getParameterHandle(_message, "is_broadcast");
            _parameterPayload = _rtiAmbassador.getParameterHandle(_message, "Payload");

            _rtiAmbassador.subscribeInteractionClass(TX_message);
            _rtiAmbassador.publishInteractionClass(RX_message);


            // Ask for the LCI to LCF coordinate system transformaton data.
            System.out.println("Waiting for reference frame conversion definitions ...");
            wait_on_reference_frame_discovery = false;
            while (wait_on_reference_frame_discovery) {
                Thread.yield();
            }
            System.out.println("Reference frames discovered");

            System.out.println("To exit, type . <ENTER>");
            while (true) {
                String payload = in.readLine();
                if (payload.equals(".")) {
                    break;
                }
            }

            _rtiAmbassador.resignFederationExecution(ResignAction.DELETE_OBJECTS_THEN_DIVEST);
            try {
                _rtiAmbassador.destroyFederationExecution(FEDERATION_NAME);
            } catch (FederatesCurrentlyJoined ignored) {
            }
            _rtiAmbassador.disconnect();
            _rtiAmbassador = null;
        } catch (Exception e) {
            Logger.getLogger(RadioNetwork.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void receiveInteraction(InteractionClassHandle interactionClass,
            ParameterHandleValueMap theParameters,
            byte[] userSuppliedTag,
            OrderType sentOrdering,
            TransportationTypeHandle theTransport,
            SupplementalReceiveInfo receiveInfo)
            throws FederateInternalError {
        if (interactionClass.equals(TX_message)) {
            if (!theParameters.containsKey(_parameterSource)) {
                System.out.println("No message.");
                return;
            }
            if (!theParameters.containsKey(_parameterDestination)) {
                System.out.println("Bad message received: No Destination.");
                return;
            }
            if (!theParameters.containsKey(_parameterSource)) {
                System.out.println("Bad message received: No Source.");
                return;
            }
            if (!theParameters.containsKey(_parameterPayload)) {
                System.out.println("Bad message received: No Message.");
                return;
            }

            try {
                // FIXME: Remove this once the correlation of satellites and radios are fixed.
                _rtiAmbassador.sendInteraction(RX_message, theParameters, null);

                HLAunicodeString sourceDecoder = _encoderFactory.createHLAunicodeString();
                HLAunicodeString destinationDecoder = _encoderFactory.createHLAunicodeString();
                HLAboolean broadcastFlagDecoder = _encoderFactory.createHLAboolean();
                HLAunicodeString payloadDecoder = _encoderFactory.createHLAunicodeString();
                sourceDecoder.decode(theParameters.get(_parameterSource));
                destinationDecoder.decode(theParameters.get(_parameterDestination));
                broadcastFlagDecoder.decode(theParameters.get(_parameterIsBroadcast));
                payloadDecoder.decode(theParameters.get(_parameterPayload));
                String source = sourceDecoder.getValue();
                String destination = destinationDecoder.getValue();
                Boolean isBroadcast = broadcastFlagDecoder.getValue();
                String payload = payloadDecoder.getValue();


                // Print the message.
                System.out.print(source + "->" + destination + ":");
                if (isBroadcast) {
                    System.out.print("[ Broadcast ]:");
                }

                System.out.println(payload);
                // Calculate whether the radios are in range of one another.
                double[] sourcePosition = getRadioPosition(source);
                double[] destPosition = getRadioPosition(destination);
                double dist = calcDistance(sourcePosition, destPosition);
                double fspl = calcFSPL(dist, RADIO_LAMBDA);
                System.out.println("Distance between nodes = " + dist + " FSPL = " + fspl);

                // Determine if we have LOS
                boolean LOS = true;
                if (LOS_ENABLED && cLOS.lineSphereIntersect(sourcePosition,
                        destPosition, ORIGIN, LUNAR_RADIUS)) {
                    LOS = !cLOS.pointInSegment(sourcePosition, destPosition,
                            ORIGIN, LUNAR_RADIUS);
                }
                System.out.println("In LOS: " + LOS);

                // If we have LOS, send the message out as a receive interaction.
                if (LOS) {
                    //_rtiAmbassador.sendInteraction(RX_message, theParameters, null);
                }
            } catch (Exception ex) {
                Logger.getLogger(RadioNetwork.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void removeObjectInstance(ObjectInstanceHandle theObject,
            byte[] userSuppliedTag,
            OrderType sentOrdering,
            SupplementalRemoveInfo removeInfo) {
        try {
            // Remove the obsolete objects from the list.
            if (entities.containsKey(theObject)) {

                // Retrieve the entity from the map.
                cEntity entity = entities.get(theObject);

                // Remove the entity from the list.
                System.out.println("Removing entity: " + entity._name);
                entities.remove(theObject);
                removeKeyfromNameHandleMap(entity.getName());
            } else if (radios.containsKey(theObject)) {

                // Retrieve the radio from the map.
                cRadio radio = radios.get(theObject);

                // Remove the radio from the list.
                System.out.println("Removing radio: " + radio._name);
                radios.remove(theObject);
                removeKeyfromNameHandleMap(radio._name);
            } else if (frames.containsKey(theObject)) {

                // Retrieve the reference frames from the map.
                cReferenceFrame reference_frame = frames.get(theObject);

                // Remove the entity from the list.
                System.out.println("Removing reference frame: " + reference_frame._name);
                frames.remove(theObject);
                removeKeyfromNameHandleMap(reference_frame._name);
            }

        } catch (Exception e) {
            Logger.getLogger(RadioNetwork.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void discoverObjectInstance(
            ObjectInstanceHandle theObject,
            ObjectClassHandle theObjectClass,
            String theObjectInstanceName) {

        try {
            while(!initialized) {
                System.out.println("waiting for initialization");
            }
            //System.out.println("Discovered object" + theObjectInstanceName);
            // Initialize the types of objects we want to discover.
            final ObjectClassHandle frameObject =
                    _rtiAmbassador.getObjectClassHandle("ReferenceFrame");
            final ObjectClassHandle radioObject =
                    _rtiAmbassador.getObjectClassHandle("Radio");
            final ObjectClassHandle entityObject =
                    _rtiAmbassador.getObjectClassHandle("PhysicalEntity");

            if (theObjectClass.equals(frameObject)) {
                System.out.println("Discovered new reference frame: " + theObjectInstanceName);
                frames.put(theObject, new cReferenceFrame(theObjectInstanceName));
                // There are 7 defined reference frames. We wait until they've all
                // been discovered before proceeding.
                if (++discovered_reference_frames >= 7) {
                    wait_on_reference_frame_discovery = false;
                }
            } else if (theObjectClass.equals(radioObject)) {
                _rtiAmbassador.requestAttributeValueUpdate(theObject, cRadio.getAttrSet(), null);
            } else if (theObjectClass.equals(entityObject)) {
                _rtiAmbassador.requestAttributeValueUpdate(theObject, cEntity.getAttrSet(), null);
            }
        } catch (Exception e) {
            Logger.getLogger(RadioNetwork.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void reflectAttributeValues(ObjectInstanceHandle theObject,
            AttributeHandleValueMap theAttributes,
            byte[] userSuppliedTag,
            OrderType sentOrdering,
            TransportationTypeHandle theTransport,
            SupplementalReflectInfo reflectInfo) {

        try {
            // If we found a new entity, add it to the list.
            if (!entities.containsKey(theObject)
                    && theAttributes.containsKey(cEntity.getAttrName())) {
                // Add the entity to the list.
                cEntity entity = new cEntity(theAttributes);
                entities.put(theObject, entity);
                addEntitytoNameHandleMap(entity._name, theObject);
            } else if (!radios.containsKey(theObject)
                    && theAttributes.containsKey(cRadio.getAttrName())) {
                // Add the radio to the list.
                cRadio radio = new cRadio(theAttributes);
                radios.put(theObject, radio);
                addRadiotoNameHandleMap(radio._name, theObject);
            }

            // Update object state.
            if (entities.containsKey(theObject)) {
                // Retrieve the entity from the map and update it's attributes.
                cEntity entity = entities.get(theObject);
                entity.update(theAttributes);
            }
        } catch (Exception e) {
            Logger.getLogger(RadioNetwork.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    @Override
    public void reflectAttributeValues(
            ObjectInstanceHandle theObject,
            AttributeHandleValueMap theAttributes,
            byte[] userSuppliedTag,
            OrderType sentOrdering,
            TransportationTypeHandle theTransport,
            LogicalTime theTime,
            OrderType receivedOrdering,
            MessageRetractionHandle retractionHandle,
            SupplementalReflectInfo reflectInfo) {
        try {
            if (frames.containsKey(theObject)) {
                cReferenceFrame frame = frames.get(theObject);
                frame.update(theAttributes);
            }
        } catch (Exception e) {
            Logger.getLogger(RadioNetwork.class.getName()).log(Level.SEVERE, null, e);
        }
    }
}
