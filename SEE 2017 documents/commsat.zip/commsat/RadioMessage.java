package commsat;

import java.util.ArrayList;
import java.util.List;

public class RadioMessage {

    private cRadio source;
    private cRadio destination;
    private String payload;
    private Status status;

    public enum Status {
        NEW("new"),
            PENDING("pending"),
            SENT("sent"),
            FAILED("failed");

        private String value;

        private Status(String value) {
            this.value = value;
        }
    }

    private static List<RadioMessage> messageList = new ArrayList<RadioMessage>();

    public static List<RadioMessage> getList() {
        return messageList;
    }

    public RadioMessage(){

    }

    /*
    public double getTransmissionDistance(){
        double[] sp = source.getPosition();
        double[] tp = destination.getPosition();
        double temp = Math.pow(sp[0]-tp[0], 2) + Math.pow(sp[1]-tp[1], 2) + Math.pow(sp[2]-tp[2], 2);
        return Math.pow(temp, .5);
    }
    */

    public RadioMessage(cRadio source, cRadio destination, String message ){
        if ( source.equals(destination) ) {
            throw new IllegalArgumentException("Source and Destination Must be Different.");
        }
        if ( !textHasContent(message) ) {
            throw new IllegalArgumentException("Message has no content.");
        }
        setSource(source);
        setDestination(destination);
        setPayload(message);
        setStatus(Status.NEW);
        messageList.add(this);
    }

    /**
     * Returns true if aText is non-null and has visible content.
     *
     * This is a test which is often performed, and should probably
     * be placed in a general utility class.
     */
    private boolean textHasContent( String aText ){
        String EMPTY_STRING = "";
        return (aText != null) && (!aText.trim().equals(EMPTY_STRING));
    }

    public cRadio getSource() {
        return source;
    }

    public void setSource(cRadio source) {
        this.source = source;
    }

    public cRadio getDestination() {
        return destination;
    }

    public void setDestination(cRadio destination) {
        this.destination = destination;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

}
