package commsat;

import hla.rti1516e.*;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.encoding.HLAfixedArray;
import hla.rti1516e.encoding.HLAfloat64LE;
import hla.rti1516e.encoding.HLAunicodeString;
import hla.rti1516e.exceptions.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class cEntity {

    // HLA stuff.
    static private RTIambassador _rtiAmbassador;
    static private EncoderFactory _encoderFactory;
    // Attributes shared by all entitites.
    static public AttributeHandle attrName;
    static private AttributeHandle attrPos;
    static private AttributeHandle attrRefFrame;
    static public AttributeHandleSet attrSet;
    static private boolean is_initialized = false;
    // Decoders that are shared be all entities.
    private final HLAunicodeString stringDecoder;
    private final HLAfixedArray<HLAfloat64LE> vectorDecoder;
    // Attributes that are unique to each entity.
    public String _name;
    public String _reference_frame;
    public double[] _position = new double[3];
    private Date updatedAt;

    /**
     * Register the objects of type radio with the RTI and initialize all of the
     * attribute handling.
     *
     * @param rtiAmbassador RTI ambassador handle.
     * @param encoderFactory Object used to create encoders.
     */
    static void hla_register(RTIambassador rtiAmbassador, EncoderFactory encoderFactory) {
        try {
            _rtiAmbassador = rtiAmbassador;
            _encoderFactory = encoderFactory;
            initAttrSet();

        } catch (Exception ex) {
            Logger.getLogger(cEntity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public cEntity(AttributeHandleValueMap attributes) {
        // Create decoders for entity object attributes.
        stringDecoder = _encoderFactory.createHLAunicodeString();
        vectorDecoder = _encoderFactory.createHLAfixedArray(
                _encoderFactory.createHLAfloat64LE(),
                _encoderFactory.createHLAfloat64LE(),
                _encoderFactory.createHLAfloat64LE());

        try {
            stringDecoder.decode(attributes.get(attrName));
            _name = stringDecoder.getValue();
            System.out.println("Discovered new entity: " + _name);
        } catch (Exception ex) {
            Logger.getLogger(cEntity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(AttributeHandleValueMap attributes) {
        try {
            // Update position.
            vectorDecoder.decode(attributes.get(attrPos));
            _position[0] = vectorDecoder.get(0).getValue();
            _position[1] = vectorDecoder.get(1).getValue();
            _position[2] = vectorDecoder.get(2).getValue();
            /*
             * System.out.println(_name + ": Position(" + _position[0] + "," +
             * _position[1] + "," + _position[2] + ")");
             */

            // Determine what coordinate frame the position was publshed in.
            if (!attributes.containsKey(attrRefFrame)) {
                //System.out.println(_name + " did not provide a reference frame");
            } else {
                stringDecoder.decode(attributes.get(attrRefFrame));
                _reference_frame = stringDecoder.getValue();
                if (!_reference_frame.equals("MoonCentricFixed")) {
                    /*
                    System.out.println(_name
                            + " is publishing position in unsupported reference frame "
                            + _reference_frame);
                            */
                }
            }

            setUpdatedAt(new Date());
        } catch (Exception ex) {
            Logger.getLogger(cEntity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static public void initAttrSet() {
        try {
            // Subcribe to entity objects.
            ObjectClassHandle entity =
                    _rtiAmbassador.getObjectClassHandle("PhysicalEntity");
            attrName = _rtiAmbassador.getAttributeHandle(entity, "entity_name");
            attrPos = _rtiAmbassador.getAttributeHandle(entity, "position");
            attrRefFrame = _rtiAmbassador.getAttributeHandle(entity, "parent_reference_frame");
            attrSet = _rtiAmbassador.getAttributeHandleSetFactory().create();

            attrSet.add(attrName);
            attrSet.add(attrPos);
            attrSet.add(attrRefFrame);

            _rtiAmbassador.subscribeObjectClassAttributes(entity, attrSet);

            is_initialized = true;
        } catch (Exception ex) {
            Logger.getLogger(cEntity.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static public AttributeHandleSet getAttrSet() {
        if(!is_initialized)
        {
            initAttrSet();
        }
        return attrSet;
    }

    static public AttributeHandle getAttrName()
    {
        if(!is_initialized)
        {
            initAttrSet();
        }

        return attrName;
    }

    public String getName() {
        return _name;
    }

    public double[] getPosition() {
        return _position;
    }

    public void setName(String name) {
        this._name = name;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}
