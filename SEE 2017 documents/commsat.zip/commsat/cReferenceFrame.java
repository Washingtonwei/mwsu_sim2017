package commsat;

import hla.rti1516e.*;
import hla.rti1516e.encoding.DecoderException;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.encoding.HLAfixedArray;
import hla.rti1516e.encoding.HLAfloat64LE;
import hla.rti1516e.exceptions.FederateNotExecutionMember;
import hla.rti1516e.exceptions.NameNotFound;
import hla.rti1516e.exceptions.NotConnected;
import hla.rti1516e.exceptions.RTIinternalError;
import java.util.logging.Level;
import java.util.logging.Logger;

public class cReferenceFrame {

    // HLA stuff.
    static private RTIambassador _rtiAmbassador;
    static private EncoderFactory _encoderFactory;
    // Attributes shared by all reference frames.
    static private AttributeHandle attrName;
    static private AttributeHandle attrParentName;
    static private AttributeHandle attrTranslation;
    static private AttributeHandle attrRotation;
    static private AttributeHandle attrTime;
    static private AttributeHandleSet attrSet;
    // Decoders that are shared be all reference frames.
    static private HLAfixedArray<HLAfloat64LE> vectorDecoder;
    // Atributes that are unique to each reference frame.
    public String _name;
    public String _parent_name;
    public double[] _translation = new double[3];
    public double[] _rotation = new double[4];
    public double _time;

    /**
     * Register the objects of type radio with the RTI and initialize all of the
     * attribute handling.
     *
     * @param rtiAmbassador RTI ambassador handle.
     * @param encoderFactory Object used to create encoders.
     */
    static void hla_register(RTIambassador rtiAmbassador, EncoderFactory encoderFactory) {
        try {
            _rtiAmbassador = rtiAmbassador;
            _encoderFactory = encoderFactory;

            // Subscribe to reference frames
            ObjectClassHandle reference_frame =
                    _rtiAmbassador.getObjectClassHandle("ReferenceFrame");
            attrName = _rtiAmbassador.getAttributeHandle(reference_frame, "name");
            attrParentName = _rtiAmbassador.getAttributeHandle(reference_frame, "parent_name");
            attrTranslation =
                    _rtiAmbassador.getAttributeHandle(reference_frame, "translational_state");
            attrRotation = _rtiAmbassador.getAttributeHandle(reference_frame, "rotational_state");
            attrTime = _rtiAmbassador.getAttributeHandle(reference_frame, "time");

            attrSet = _rtiAmbassador.getAttributeHandleSetFactory().create();
            attrSet.add(attrName);
            attrSet.add(attrParentName);
            attrSet.add(attrTranslation);
            attrSet.add(attrRotation);
            attrSet.add(attrTime);

            // Create decoders for entity object attributes.
            vectorDecoder = _encoderFactory.createHLAfixedArray(
                    _encoderFactory.createHLAfloat64LE(),
                    _encoderFactory.createHLAfloat64LE(),
                    _encoderFactory.createHLAfloat64LE());

            //_rtiAmbassador.subscribeObjectClassAttributes(reference_frame, attrSet);
        } catch (Exception ex) {
            Logger.getLogger(cReferenceFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public cReferenceFrame(String name) {
        _name = name;
        System.out.println("Discovered new reference_frame: " + _name);
    }

    public void update(AttributeHandleValueMap attributes) {
        try {
            // Update translation.
            /* FIXME Comment out the decoding of translations for now because
             * the decoder throws a divide by zero exception on the MAK RTI.
             * We don't need this code reight now anyway.
            vectorDecoder.decode(attributes.get(attrTranslation));
            _translation[0] = vectorDecoder.get(0).getValue();
            _translation[1] = vectorDecoder.get(1).getValue();
            _translation[2] = vectorDecoder.get(2).getValue();
             */
            //System.out.println(_name + ": Translation(" + _translation[0] + "," +
            //    _translation[1] + "," + _translation[2] + ")");
        } catch (Exception ex) {
            Logger.getLogger(cReferenceFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
