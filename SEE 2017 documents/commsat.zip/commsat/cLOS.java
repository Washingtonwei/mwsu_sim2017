package commsat;

public class cLOS {

     static private final double[] ORIGIN = {0, 0, 0};
     static private final double RADIUS = 2;

    /**
     * Calculate the intersection of a ray and a sphere The line segment is
     * defined from p1 to p2 The sphere is of radius r and centered at sc
     *
     * Algorithm adapted from http://paulbourke.net/geometry/sphereline/
     *
     * @param p1 First point
     * @param p2 Second point
     * @param sc Center of the sphere
     * @param r Radius of the sphere
     * @return true if the ray intersects the shere
     */
    public static boolean lineSphereIntersect(double[] p1, double[] p2,
            double[] sc, double r) {
        double a, b, c;
        double bb4ac;
        double[] dp = new double[3];

        dp[0] = p2[0] - p1[0];
        dp[1] = p2[1] - p1[1];
        dp[2] = p2[2] - p1[2];
        a = dp[0] * dp[0] + dp[1] * dp[1] + dp[2] * dp[2];
        b = 2 * (dp[0] * (p1[0] - sc[0]) + dp[1] * (p1[1] - sc[1]) + dp[2] *
                (p1[2] - sc[2]));
        c = sc[0] * sc[0] + sc[1] * sc[1] + sc[2] * sc[2];
        c += p1[0] * p1[0] + p1[1] * p1[1] + p1[2] * p1[2];
        c -= 2 * (sc[0] * p1[0] + sc[1] * p1[1] + sc[2] * p1[2]);
        c -= r * r;
        bb4ac = b * b - 4 * a * c;
        if (Math.abs(a) < 1e-10 || bb4ac <= 0) {
            return false;
        }

        return true;
    }


    /**
     * Determine if the closest point on a line passing through points p1 and
     * p2 lies between p1 and p2.
     *
     * Algorithm adapted from http://paulbourke.net/geometry/sphereline/
     *
     * @param p1 First point
     * @param p2 Second point
     * @param sc Center of the sphere
     * @param r Radius of the sphere
     * @return true if the closest point on the line defined by p1 and p2 lies
     * between points p1 and p2.
     */
    public static boolean pointInSegment(double[] p1, double[] p2,
            double[] sc, double r) {
        double dx = p2[0]-p1[0];
        double dy = p2[1]-p1[1];
        double dz = p2[2]-p1[2];
        double u = ((sc[0]-p1[0])*dx+(sc[1]-p1[1])*dy+(sc[2]-p1[2])*dz) /
            (dx*dx+dy*dy+dz*dz);
        System.out.println("u = " + u);
        return (u > 0.0) && (u < 1.0);
    }


    public static void testBaseTo45() {
        double [] p1 = {RADIUS + 2, 2, 0};
        double [] p2 = {RADIUS, 0, 0};
        boolean lsi = lineSphereIntersect(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: lineSphereIntersect : " + lsi);
        boolean pis = pointInSegment(p1, p2, ORIGIN, RADIUS);
        System.out.println("FALSE: pointInSegment : " + pis);
        boolean inLOS = (false == lsi) || ((lsi && (false == pis)));
        System.out.println("TRUE: inLOS : " + inLOS);
    }


    public static void testBaseToFarTangent() {
        double [] p1 = {RADIUS - 0.1, 2, 0};
        double [] p2 = {RADIUS, 0, 0};
        boolean lsi = lineSphereIntersect(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: lineSphereIntersect : " + lsi);
        boolean pis = pointInSegment(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: pointInSegment : " + pis);
        boolean inLOS = (false == lsi) || ((lsi && (false == pis)));
        System.out.println("FALSE: inLOS : " + inLOS);
    }


    public static void testBaseToNearTangent() {
        double [] p1 = {RADIUS + 0.1, 2, 0};
        double [] p2 = {RADIUS, 0, 0};
        boolean lsi = lineSphereIntersect(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: lineSphereIntersect : " + lsi);
        boolean pis = pointInSegment(p1, p2, ORIGIN, RADIUS);
        System.out.println("FALSE: pointInSegment : " + pis);
        boolean inLOS = (false == lsi) || ((lsi && (false == pis)));
        System.out.println("TRUE: inLOS : " + inLOS);
    }


    public static void testBaseToTangent() {
        double [] p1 = {RADIUS, 0, 0};
        double [] p2 = {RADIUS, 2, 0};
        boolean lsi = lineSphereIntersect(p1, p2, ORIGIN, RADIUS);
        System.out.println("FALSE: lineSphereIntersect : " + lsi);
        boolean pis = pointInSegment(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: pointInSegment : " + pis);
        boolean inLOS = (false == lsi) || ((lsi && (false == pis)));
        System.out.println("TRUE: inLOS : " + inLOS);
    }


    public static void testBaseToBehindMoon() {
        double [] p1 = {RADIUS, 0, 0};
        double [] p2 = {-1 * (RADIUS + 2), 0, 0};
        boolean lsi = lineSphereIntersect(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: lineSphereIntersect : " + lsi);
        boolean pis = pointInSegment(p1, p2, ORIGIN, RADIUS);
        System.out.println("FALSE: pointInSegment : " + pis);
        boolean inLOS = (false == lsi) || ((lsi && (false == pis)));
        System.out.println("FALSE: inLOS : " + inLOS);
    }


    public static void testBaseToOverhead() {
        double [] p1 = {RADIUS, 0, 0};
        double [] p2 = {RADIUS + 2, 0, 0};
        boolean lsi = lineSphereIntersect(p1, p2, ORIGIN, RADIUS);
        System.out.println("TRUE: lineSphereIntersect : " + lsi);
        boolean pis = pointInSegment(p1, p2, ORIGIN, RADIUS);
        System.out.println("FALSE: pointInSegment : " + pis);
        boolean inLOS = (false == lsi) || ((lsi && (false == pis)));
        System.out.println("TRUE: inLOS : " + inLOS);
    }


    /**
     * @param args the command line arguments
    public static void main(String[] args) {
        cLOS.testBaseToOverhead();
        cLOS.testBaseToBehindMoon();
        cLOS.testBaseToTangent();
        cLOS.testBaseToNearTangent();
        cLOS.testBaseToFarTangent();
        cLOS.testBaseTo45();
    }
     */
}
