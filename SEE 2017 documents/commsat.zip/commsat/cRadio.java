package commsat;

import hla.rti1516e.*;
import hla.rti1516e.encoding.EncoderFactory;
import hla.rti1516e.encoding.HLAfloat32LE;
import hla.rti1516e.encoding.HLAunicodeString;
import hla.rti1516e.exceptions.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class cRadio {

    // HLA stuff.
    static private RTIambassador _rtiAmbassador;
    static private EncoderFactory _encoderFactory;
    // Attributes shared by all radios.
    static public AttributeHandle attrName;
    static private AttributeHandle attrElevation;
    static private AttributeHandle attrTxPower;
    static private AttributeHandle attrTxFreq;
    static private AttributeHandle attrTxEnable;
    static private AttributeHandle attrRxReqSignalStr;
    static private AttributeHandle attrRxFreq;
    static private AttributeHandle attrRxEnable;
    static private AttributeHandle attrIsRouter;
    static private AttributeHandleSet attrSet;
    static private boolean is_initialized = false;
    // Decoders that are shared be all entities.
    private final HLAunicodeString stringDecoder;
    private final HLAfloat32LE floatDecoder;
    // Attributes that are unique to each radio.
    public String _name;
    public cEntity _owner;
    private Float _txPower;
    private Boolean _txEnable;
    private Float _rxReqSigStr;
    private Float _rxFreq;
    private Boolean _rxEnable;
    private Double _elevation;
    private boolean _isRouter;
    private Date updatedAt;

    /**
     * Register the objects of type radio with the RTI and initialize all of the
     * attribute handling.
     *
     * @param rtiAmbassador RTI ambassador handle.
     * @param encoderFactory Object used to create encoders.
     */
    static void hla_register(RTIambassador rtiAmbassador, EncoderFactory encoderFactory) {
        try {
            _rtiAmbassador = rtiAmbassador;
            _encoderFactory = encoderFactory;
            initAttrSet();

        } catch (Exception ex) {
            Logger.getLogger(cRadio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public cRadio(AttributeHandleValueMap attributes) {
        // Create decoders for radio object attributes.
        stringDecoder = _encoderFactory.createHLAunicodeString();
        floatDecoder = _encoderFactory.createHLAfloat32LE();

        try {
            stringDecoder.decode(attributes.get(attrName));
            _name = stringDecoder.getValue();
            if (attributes.containsKey(attrTxPower)) {
                floatDecoder.decode(attributes.get(attrTxPower));
                _txPower = floatDecoder.getValue();
            } else {
                _txPower = (float) 10.0;
            }
            if (attributes.containsKey(attrRxReqSignalStr)) {
                floatDecoder.decode(attributes.get(attrRxReqSignalStr));
                _rxReqSigStr = floatDecoder.getValue();
            } else {
                _rxReqSigStr = (float) 0.001;
            }

            // FIXME: This should come from the radio message.
            _elevation = 2.0;

            System.out.println("Discovered new radio: " + _name);
        } catch (Exception ex) {
            Logger.getLogger(cRadio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    static public void initAttrSet() {

            try {
                // Subscribe to radio objects
                ObjectClassHandle radio = _rtiAmbassador.getObjectClassHandle("Radio");
                attrName = _rtiAmbassador.getAttributeHandle(radio, "radio_name");
                attrElevation = _rtiAmbassador.getAttributeHandle(radio, "elevation");
                attrTxPower = _rtiAmbassador.getAttributeHandle(radio, "TX_power");
                attrRxReqSignalStr = _rtiAmbassador.getAttributeHandle(radio,
                        "RX_required_signal_strength");

                attrSet = _rtiAmbassador.getAttributeHandleSetFactory().create();
                attrSet.add(attrName);
                attrSet.add(attrElevation);
                attrSet.add(attrTxPower);
                attrSet.add(attrRxReqSignalStr);
                _rtiAmbassador.subscribeObjectClassAttributes(radio, attrSet);

                is_initialized = true;
            } catch (Exception ex) {
                Logger.getLogger(cRadio.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    static public AttributeHandleSet getAttrSet() {
        if(!is_initialized)
        {
            initAttrSet();
        }
        return attrSet;
    }

    static public AttributeHandle getAttrName()
    {
        if(!is_initialized)
        {
            initAttrSet();
        }

        return attrName;
    }

    public double getElevation() {
        return _elevation;
    }

    public double[] getPosition() {
        double[] position = _owner.getPosition();
        /// @todo fix this equation to divide the elevation into the x, y, and z components.
        position[0] += _elevation;
        position[1] += _elevation;
        position[2] += _elevation;
        return position;
    }
}
